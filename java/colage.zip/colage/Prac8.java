import java.util.Scanner;

public class HittingTheDeck {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read the number of cards in the deck
        int n = sc.nextInt();

        // Game logic:
        // If n is divisible by 3, Player 2 wins, else Player 1 wins
        if (n % 3 == 0) {
            System.out.println("Player 2");
        } else {
            System.out.println("Player 1");
        }

        sc.close();
    }
}
